document.getElementById("consultationForm").addEventListener("submit", function(event) {
    event.preventDefault();
    
    let name = document.getElementById("name").value;
    let email = document.getElementById("email").value;
    let phone = document.getElementById("phone").value;
    let country = document.getElementById("country").value;
    
    if (!name || !email || !phone || !country) {
        alert("Please fill in all fields.");
        return;
    }
    
    alert("Thank you, " + name + "! We will contact you soon.");
    document.getElementById("consultationForm").reset();
});

function scrollToForm() {
    document.querySelector(".lead-form").scrollIntoView({ behavior: "smooth" });
}
const scrollContainer = document.querySelector(".countries-grid");

let isDown = false;
let startX;
let scrollLeft;

scrollContainer.addEventListener("mousedown", (e) => {
    isDown = true;
    scrollContainer.classList.add("active");
    startX = e.pageX - scrollContainer.offsetLeft;
    scrollLeft = scrollContainer.scrollLeft;
});

scrollContainer.addEventListener("mouseleave", () => {
    isDown = false;
    scrollContainer.classList.remove("active");
});

scrollContainer.addEventListener("mouseup", () => {
    isDown = false;
    scrollContainer.classList.remove("active");
});

scrollContainer.addEventListener("mousemove", (e) => {
    if (!isDown) return;
    e.preventDefault();
    const x = e.pageX - scrollContainer.offsetLeft;
    const walk = (x - startX) * 2; // Adjust scrolling speed
    scrollContainer.scrollLeft = scrollLeft - walk;
});
